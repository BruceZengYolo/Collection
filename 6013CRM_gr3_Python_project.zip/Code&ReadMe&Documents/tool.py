import re
import pdfplumber
import pandas as pd


def get_all_from_pdf(pdf):
    '''获得pdf的文本，从第三页开始'''

    text = ""
    pages_num = len(pdf.pages)
    num_list = list(range(0, pages_num))
    for i in num_list:
        text += pdf.pages[i].extract_text()
    return text


def get_sections(text, sections_re):
    '''获得段落的文本'''

    a = None
    result = []
    for i in sections_re:
        # print(i)
        a = i.search(text)
        # print(a)
        if a: result.append(a.group(1))
    return result


def get_goal_text(goal_text_re, section):
    '''获取段落中包含目标的一段文本'''

    goal_text = {}
    for k, v in goal_text_re.items():
        goal_text[k] = []
        # print(v)
        for i, j in v.findall(section):
            # print(i,j,v)
            goal_text[k].append(i)
    return goal_text  


def get_indicators(text, indicator_re):
    '''获得一段文本中的（集团或公司的）指标数据'''

    result = indicator_re.search(text)
    if result: return result
    return None

def get_all_indicators(text, indicator_re):
    result = indicator_re.findall(text)
    if result: return result
    return None


def write_to_excel(file_name, indicators_data):
    '''把指标数据输出到excel'''

    df = pd.DataFrame(indicators_data, columns=["分类1","分类2","指标名","指标值","变化"])
    w = pd.ExcelWriter("%s.xlsx" % file_name)
    df.to_excel(w, sheet_name="Sheet1", header=True, index=False)
    w.close()


# 一般的数据清洗函数，用于去掉空格
def clean_data(text):
    result = re.sub(" ","",text)
    return result