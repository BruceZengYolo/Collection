import re
import pdfplumber
import pandas as pd
from setting import on_off
from setting import clean_text
import sys
from sys import exit
import copy




qybd_cal = [["公告日期", "公司名","信息披露义务人", "权益变动前股东持股数量（股）",
             "权益变动前股东持股比例（%）", "权益变动后股东持股数量（股）",
             "权益变动后股东持股比例（%）","权益变动原因"]]
shougou_cal = [["公告日期", "公司名", "划出方", "划入方",
                "划转标的（股）", "标的占划出方持有公司股份比例（%）",
                "收购前股东持股数量（股）", "收购前持有公司占比（%）",
                "收购后股东持股数量（股）","收购后持有公司占比（%）"]]
# =================== 打开PDF文件 ===================

# from setting import path, kb_file, pdf_file_l
from setting import path, pdf_file_l
while(True):
    useros = input("Please enter the OS you are using: 1. MacOS 2. Windows\n")
    if(useros == '2'):
        from setting import path_win as path
        break
    elif(useros == '1'):
        break
    else:
        print("Invalid Input.")
from dictionary import indicators_re_ge
from setting import qybd_sections_re, shougou_sections_re
base_indicators_re = copy.deepcopy(indicators_re_ge)
base_qybd_sections_re = copy.deepcopy(qybd_sections_re)
base_shougou_sections_re = copy.deepcopy(shougou_sections_re)

for pdf_file in pdf_file_l:
    indicators_re = copy.deepcopy(base_indicators_re)
    qybd_sections_re = copy.deepcopy(base_qybd_sections_re)
    shougou_sections_re = copy.deepcopy(base_shougou_sections_re)
    from setting import shougou_sections_re as shougou_sections_re
    try:
        pdf = pdfplumber.open(r"%s" % path + pdf_file)
    except FileNotFoundError:
        print("没有找到文件\n")
        exit(2)
    pdf_file_fn = path + pdf_file
    # =================== 打开PDF文件 ===================
    
    
    
    # =================== 读取文件 ===================
    from tool import get_all_from_pdf
    print("读取文件...")

    pdf_text = get_all_from_pdf(pdf)
    # kb_df = pd.read_excel(path + kb_file)
    # =================== 读取文件 ===================
    
    print("处理文件: " + pdf_file)
    # =================== 提取包含指标的段落 ===================
    from tool import get_sections
    
    if "权益变动" in on_off:
        from setting import qybd_sections_re
        qybd_sections_re = copy.deepcopy(base_qybd_sections_re)
        if(pdf_file.count('中国邮政储蓄银行') and pdf_file.count('提示性')):
            from setting import qybd_sections_yzcx_re
            qybd_sections_re = qybd_sections_yzcx_re
        if(pdf_file.count("交通银行") or pdf_file.count("农业银行") or pdf_file.count("工商银行")):
            from setting import qybd_sections_jtnygs_re
            qybd_sections_re = qybd_sections_jtnygs_re
        if(pdf_file.count("光大银行")):
            from setting import qybd_sections_guangda_re
            qybd_sections_re = qybd_sections_guangda_re
        if(pdf_file.count("成都银行") and pdf_file.count("权益变动") and pdf_file.count("0306")):
            from setting import qybd_sections_chengdu0306_re
            qybd_sections_re = qybd_sections_chengdu0306_re
        if(pdf_file.count("成都银行") and pdf_file.count("权益变动") and pdf_file.count("0703")):
            from setting import qybd_sections_chengdu0703_re
            qybd_sections_re = qybd_sections_chengdu0703_re
        if(pdf_file.count("长沙银行") and pdf_file.count("权益变动")):
            from setting import qybd_sections_changsha_re
            qybd_sections_re = qybd_sections_changsha_re
        if(pdf_file.count("青农商行") and pdf_file.count("权益变动")):
            from setting import qybd_sections_qingnong_re
            qybd_sections_re = qybd_sections_qingnong_re
        if(pdf_file.count("招商银行") and pdf_file.count("权益变动")):
            from setting import qybd_sections_zhaoshang_re
            qybd_sections_re = qybd_sections_zhaoshang_re
        if(pdf_file.count("北京银行") and pdf_file.count("权益变动")):
            from setting import qybd_sections_beijing_re
            qybd_sections_re = qybd_sections_beijing_re
        if(pdf_file.count("民生银行") and pdf_file.count("权益变动")):
            from setting import qybd_sections_minsheng_re
            qybd_sections_re = qybd_sections_minsheng_re
        if(pdf_file.count("郑州银行") and pdf_file.count("权益变动")):
            from setting import qybd_sections_zhengzhou_re
            qybd_sections_re = qybd_sections_zhengzhou_re
        if(pdf_file.count("杭州银行")):
            from setting import qybd_sections_hzyh_re
            qybd_sections_re = qybd_sections_hzyh_re
        
        qybd_sections = get_sections(pdf_text, qybd_sections_re)
    
    if "收购" in on_off:
        from setting import shougou_sections_re
        if(pdf_file.count('成都银行')):
            from setting import shougou_sections_cd_re as shougou_sections_re
        shougou_sections = get_sections(pdf_text, shougou_sections_re)
    # =================== 提取包含指标的段落 ===================
    
    
    # =================== 从段落中获得包含指标的目标文本 ===================
    from tool import get_goal_text
    from setting import qybd_goal_text_re

    if "权益变动" in on_off:
        
        qybd_goal_text = {}
        for section in qybd_sections:
            if len(qybd_goal_text) == 0:
                qybd_goal_text = get_goal_text(qybd_goal_text_re, clean_text(section))
                continue
            tmp = get_goal_text(qybd_goal_text_re, clean_text(section)).items()
            for k, v in get_goal_text(qybd_goal_text_re, clean_text(section)).items():
                qybd_goal_text[k].extend(v)
    
    if "收购" in on_off:
        from setting import shougou_goal_text_re
        shougou_goal_text = {}
        for section in shougou_sections:
            if len(shougou_goal_text) == 0:
                shougou_goal_text = get_goal_text(shougou_goal_text_re, clean_text(section))
                continue
            for k, v in get_goal_text(shougou_goal_text_re, clean_text(section)).items():
                shougou_goal_text[k].extend(v)
    # =================== 从段落中获得包含指标的目标文本 ===================
    # =================== 从PDF的表格中提取指标 ===================
    from tableextract import *
    table = extract_tables_from_pdf(pdf_file_fn)
    
    if(len(qybd_goal_text)) == 0:
        for k in list(qybd_goal_text_re.keys()):
            qybd_goal_text[k] = []
    df_1 = get_df(pdf_file, table)
    qybd_df = pd.DataFrame()
    for k in df_1:
        for t in k:
            test = k.columns.to_list()
            if(test.count('信息披露义务人') and test.count('权益变动前') and test.count('权益变动前')):
                qybd_df = k
    
    if(len(qybd_df) != 0):
        qybd_df_filter = qybd_df[qybd_df['信息披露义务人'] == '合计']
        qybd_value = qybd_df_filter.values.tolist()
        columns = qybd_df_filter.columns.to_list()
        col = ['', '数量', '占比', '数量', '占比']
        st = ''
        for k in range(len(col)):
            if(columns[k] == None):
                col[k] = str(columns[k - 1]) + col[k]
            else:    
                col[k] = str(columns[k]) + col[k]
            st = st + col[k] + qybd_value[0][k] + '\n'
        
        qybd_goal_text["权益变动情况"].append(st)
        
    #提示性文件
    table1 = []
    if(pdf_file.count('提示性') or (pdf_file.count('%') and pdf_file.count('公告'))):
        table1 = []
        for k in range(len(pdf.pages)):
            temp = pdf.pages[k].extract_table()
            if(temp):
                table1 = table1 + temp
            
        first = -1
        second = -1
        third = -1
        for k in range(len(table1)):
            if(table1[k][0] == None):
                continue
            if(table1[k][0].find('2.') >= 0):
                first = k
            if(table1[k][0].find('3.') >= 0):
                second = k
            if(table1[k][0].find('4.') >= 0):
                third = k
        
        st = ''
        for idx in range(first):
            for t in table1[idx]:
                if(t == None):
                    st = st + ' '
                else:
                    t = t.replace('□', '?')
                    t = t.replace('', '!')
                    if(t.find('?') >= 0 and t.find('!') >= 0):
                        no = t.find('?')
                        yes = t.find('!')
                        if(no > yes):
                            t = t[0:yes]
                        else:
                            fl = no
                            while(no < yes and fl >= 0):
                                fl = t.find('?', fl + 1)
                                no = max(no, fl)
                            t = t[no + 1:yes]
                    st = st + t + ' '
            st = st + '\n'
        qybd_goal_text["信息披露义务人情况"].append(st)
        qybd_goal_text["权益变动情况"].append(st)
        
        st = ''
        for idx in range(first + 2, second):
            idx1 = first + 1
            if(table1[idx][0].count('变动方式') == 0):
                for p in range(len(table1[idx1])):
                    if(table1[idx1][p] != None and table1[idx][p] != None):
                        if(table1[idx][p] == '-'):
                            table1[idx][p] = '0'
                        st = st + table1[idx1][p] + ' ' + table1[idx][p] + ' ' + '\n'
            else:
                for p in range(len(table1[idx])):
                    if(table1[idx][p] != None):
                        table1[idx][p] = table1[idx][p].replace('□', '?')
                        table1[idx][p] = table1[idx][p].replace('', '!')
                        
                        if(table1[idx][p].count('?') > 0 and table1[idx][p].count('!') > 0):
                            no = table1[idx][p].find('?')
                            yes = table1[idx][p].find('!')
                            if(no > yes):
                                table1[idx][p] = table1[idx][p][0:yes]
                            else:
                                fl = no
                                while(no < yes and fl >= 0):
                                    fl = table1[idx][p].find('?', fl + 1)
                                    no = max(no, fl)
                                table1[idx][p] = table1[idx][p][no + 1:yes]
                        st = st + table1[idx][p] + ' '
                st = st + '\n'
                break
        qybd_goal_text["信息披露义务人情况"].append(st)
        qybd_goal_text["权益变动情况"].append(st)
            
        st = ''
        for idx in range(second + 3, third):
            for k in range(len(table1[idx])):
                if(table1[second + 1][k] == None):
                    table1[second + 1][k] = ''
                if(table1[second + 2][k] == None):
                    table1[second + 2][k] = ''
                if(table1[idx][k] != None):
                    table1[second + 1][k] = table1[second + 1][k].replace('\n', '')
                    table1[second + 2][k] = table1[second + 2][k].replace('\n', '')
                    table1[idx][k] = table1[idx][k].replace('\n', '')
                    st = st + table1[idx][0] + ' ' + table1[second + 1][k] + ' ' +table1[second + 2][k] + ' '  + table1[idx][k] + '\n'
        idx_xz = st.find('有限售条件')
        if(idx_xz > 0):
            stt = st[idx_xz:]
            f1 = re.findall('(\d+.*)', stt)
            if(len(f1) == 4):
                st = st + "股份限制情况 交易前持有限制股份数量为" + f1[0] + ". 交易后持有限制股份数量为" + f1[2] + '. \n'
            else:
                st = st + "股份限制情况 无股份限制情况\n"
        qybd_goal_text["权益变动情况"].append(st)
        
        if(pdf_file.count("中国邮政储蓄银行")):
            for i in range(2, len(table1[2])):
                st = st + '邮政集团 '
                for j in range(3):
                    if(table1[j][i] == None):
                        table1[j][i] = ' '
                    st = st + table1[j][i] + ' '
                st = st + '\n'
            st = st + "股份限制情况 无股份限制情况\n"
            qybd_goal_text["权益变动情况"].append(st)
    if(pdf_file.count("光大银行") and pdf_file.count("权益变动")):
        table1 = table[0]
        st = ""
        for i in range(len(table1)):
            if(table1[i][0].count('一致行动人')):
                st = st + '一致行动人 ' + table1[i][2] + '\n'
                break
        qybd_goal_text["信息披露义务人情况"].append(st)
    if(pdf_file.count("收购")):
        table1 = table[-1]
        for i in range(len(table1)):
            for j in range(len(table1[i])):
                table1[i][j] = clean_text(table1[i][j])
        for i in range(len(table1)):
            if(table1[i][0].count("是否免于发出要约")):
                cont = table1[i][1]
                yes = cont.find("√")
                no = cont.find("□")
                if(yes < no):
                    cont = cont[0:yes]
                elif(yes > no):
                    cont = cont[no:yes]
                st = table1[i][0] + ' '
                if(cont.count("是")):
                    st = st + "免于发出要约" + "\n"
                if(cont.count("否")):
                    st = st + "发出要约" + "\n"
                shougou_goal_text["收购事件"].append(st)
                break
    if(pdf_file.count("民生银行") and pdf_file.count("权益变动")):
        found = False
        for t in table:
            for tt in t:
                if(tt[0] == None):
                    break
                if(tt[0].count("信息披露义务人披露前") and tt[0].count("权益的股份数量")):
                    st = ""
                    st = st + "权益变动前 " + tt[1] + '\n'
                    qian = tt[1]
                    qybd_goal_text["权益变动情况"].append(st)
                    found = True
                    break
            if(found):
                break
        found = False
        for t in table:
            for tt in t:
                if(tt[0] == None):
                    break
                if(tt[0].count("权益变动后") and tt[0].count("股份数量")):
                    st = ""
                    if(not bool(re.search(r'\d', tt[1]))):
                        st = st + "权益变动后 " + qian + '\n'
                    else:
                        st = st + "权益变动后 " + tt[1] + '\n'
                    qybd_goal_text["权益变动情况"].append(st)
                    found = True
                    break
            if(found):
                break
        found = False
        for t in table:
            for tt in t:
                if(tt[0] == None):
                    break
                if(tt[0].count("权益变动方式")):
                    cont = clean_text(tt[1])
                    yes = cont.find("√")
                    no = cont.find("□")
                    if(yes < no):
                        contt = cont[0:yes]
                    elif(yes > no):
                        no_i = no
                        while(no_i < yes and no_i != -1):
                            no_i = cont.find("□", no + 1)
                            if(no_i != - 1 and no_i < yes):
                                no = no_i
                            
                        contt = cont[no + 1:yes]
                        if(contt.count("其他") or contt.count("其它")):
                            contt = "其他: " + cont[yes + 1:]
                    st = clean_text(tt[0]) + ' ' + contt
                    qybd_goal_text["权益变动情况"].append(st)
                    found = True
                    break
            if(found):
                break
                    
    if(pdf_file.count("郑州银行") and pdf_file.count("权益变动")):
        found = False
        for t in table:
            for tt in t:
                if(tt[0] == None):
                    break
                if(tt[0].count("信息披露义务人") and tt[0].count("前拥有权益")):
                    st = ""
                    st = st + "权益变动前 " + tt[1] + '\n'
                    qian = tt[1]
                    qybd_goal_text["权益变动情况"].append(st)
                    found = True
                    break
            if(found):
                break
        found = False
        for t in table:
            for tt in t:
                if(tt[0] == None):
                    break
                if(tt[0].count("权益变动后") and tt[0].count("股份数量")):
                    st = ""
                    if(not bool(re.search(r'\d', tt[1]))):
                        st = st + "权益变动后 " + qian + '\n'
                    else:
                        st = st + "权益变动后 " + tt[1] + '\n'
                    qybd_goal_text["权益变动情况"].append(st)
                    found = True
                    break
            if(found):
                break
        found = False
        for t in table:
            for tt in t:
                if(tt[0] == None):
                    break
                if(tt[0].count("权益变动方式")):
                    cont = clean_text(tt[1])
                    contt = cont
                    yes = cont.find("☑")
                    no = cont.find("□")
                    if(yes < no):
                        contt = cont[0:yes]
                    elif(yes > no):
                        no_i = no
                        while(no_i < yes and no_i != -1):
                            no_i = cont.find("□", no + 1)
                            if(no_i != - 1 and no_i < yes):
                                no = no_i
                            
                        contt = cont[no + 1:yes]
                        if(contt.count("其他") or contt.count("其它")):
                            contt = "其他: " + cont[yes + 1:]
                    st = clean_text(tt[0]) + ' ' + contt
                    qybd_goal_text["权益变动情况"].append(st)
                    found = True
                    break
            if(found):
                break
    
    # =================== 从PDF的表格中提取指标 ===================
    
    # =================== 从包含指标的目标文本提取指标 ===================
    from tool import get_indicators
    from tool import get_all_indicators
    indicators_re = {}
    from dictionary import indicators_re_ge
    indicators_re = indicators_re_ge
    # indic 和 temp 是临时变量
    indic = None
    temp = None
    qybd_indicators_value = []
    shougou_indicators_value = []
    if "权益变动" in on_off:
        if(pdf_file.count('收购') == 0):
            qybd_lib = {"公告日期": "", "公司名": "","信息披露义务人": "", "权益变动前股东持股数量（股）": "", "权益变动前股东持股比例（%）": "", "权益变动后股东持股数量（股）": "", "权益变动后股东持股比例（%）": "","权益变动原因": ""}
            from setting import qybd_indicators as qybd_indicators
            from dictionary import indicators_re_ge
            indicators_re = copy.deepcopy(base_indicators_re)
            if(pdf_file.count("提示性") or (pdf_file.count("公告") and pdf_file.count("超过"))):
                from setting import qybd_indicators_tishi as qybd_indicators
                from dictionary import indicators_tishi_re
                indicators_re = indicators_tishi_re
                if(pdf_file.count("中国邮政储蓄银行")):
                    from dictionary import indicators_tishi_yzcx_re
                    indicators_re = indicators_tishi_yzcx_re
                if(pdf_file.count("杭州银行")):
                    from dictionary import indicators_tishi_hzyh_re
                    indicators_re = indicators_tishi_hzyh_re
            elif(pdf_file.count("青岛银行")):
                from dictionary import indicators_qdyh_re as indicators_re
            elif(pdf_file.count("长沙银行")):
                from dictionary import indicators_changsha_re
                indicators_re.update(indicators_changsha_re)
            elif(pdf_file.count("成都银行") and pdf_file.count("0306")):
                from dictionary import indicators_cdyh0306_re
                indicators_re.update(indicators_cdyh0306_re)
            elif(pdf_file.count("成都银行") and pdf_file.count("0703")):
                from dictionary import indicators_cdyh0703_re
                indicators_re.update(indicators_cdyh0703_re)
            elif(pdf_file.count("青农商行")):
                from dictionary import indicators_qingnong_re
                indicators_re.update(indicators_qingnong_re)
            elif(pdf_file.count("光大银行")):
                from dictionary import indicators_guangda_re
                indicators_re.update(indicators_guangda_re)
            elif(pdf_file.count("招商银行")):
                from dictionary import indicators_zhaoshang_re
                indicators_re.update(indicators_zhaoshang_re)
            elif(pdf_file.count("北京银行")):
                from dictionary import indicators_beijing_re
                indicators_re.update(indicators_beijing_re)
            elif(pdf_file.count("民生银行")):
                from dictionary import indicators_minsheng_re
                indicators_re.update(indicators_minsheng_re)
            elif(pdf_file.count("郑州银行")):
                from dictionary import indicators_zhengzhou_re
                indicators_re.update(indicators_zhengzhou_re)
            
            for sort, texts in qybd_goal_text.items():
                for text in texts:
                    for indicator_name in qybd_indicators[sort]:
                        indic = get_indicators(text, indicators_re[indicator_name])
                        if indic:
                            temp = list( ("权益变动", sort)+indic.groups() )
                            temp[2] = indicator_name
                            if(indicator_name.count('权益变动前股东持股')):
                                if(temp[3].count('未持有')):
                                    temp[3] = '0';
                                else:
                                    if(pdf_file.count("青岛银行") and temp[2].count('数量')):
                                       temp[3] = re.search("(，信息\D*)([\d,]*)",temp[3]).group(2)
                                    if(pdf_file.count("青岛银行") and temp[2].count('占比')):
                                       temp[3] = re.search("(，信息[\S\s]*占\D*)([\d,.%]*)",temp[3]).group(2)
                            if(indicator_name == "一致行动人"):
                                temp[3] = re.sub('\d', '', temp[3])
                                if(pdf_file.count("郑州银行")):
                                    multi = ''
                                    multitemp = get_all_indicators(text,indicators_re[indicator_name])
                                    for tmp in multitemp:
                                        for tp in tmp:
                                            multi = multi + tp
                                    temp[3] = multi
                            qybd_indicators_value.append(temp)
                            temp[3] = re.sub("\s", "", temp[3])
                            if(indicator_name == "签署日期" or indicator_name == "权益变动日期"):
                                qybd_lib["公告日期"] = temp[3]
                            elif(indicator_name == "上市公司名称"):
                                qybd_lib["公司名"] = temp[3]
                            elif(indicator_name == "信息披露义务人"):
                                qybd_lib["信息披露义务人"] = temp[3]
                            elif(indicator_name == "权益变动前股东持股数量"):
                                if(temp[3].count("未") or temp[3].count("不再")):
                                    temp[3] = "0"
                                temp[3] = re.sub("股", "", temp[3])
                                qybd_lib["权益变动前股东持股数量（股）"] = temp[3]
                            elif(indicator_name == "权益变动前股东持股占比"):
                                if(temp[3].count("未") or temp[3].count("不再")):
                                    temp[3] = "0"
                                temp[3] = re.sub("%", "", temp[3])
                                temp[3] = re.sub("。", "", temp[3])
                                qybd_lib["权益变动前股东持股比例（%）"] = temp[3]
                            elif(indicator_name == "权益变动后股东持股数量"):
                                if(temp[3].count("未") or temp[3].count("不再")):
                                    temp[3] = "0"
                                temp[3] = re.sub("股", "", temp[3])
                                qybd_lib["权益变动后股东持股数量（股）"] = temp[3]
                            
                            elif(indicator_name == "权益变动后股东持股占比"):
                                if(temp[3].count("未") or temp[3].count("不再")):
                                    temp[3] = "0"
                                temp[3] = re.sub("%", "", temp[3])
                                temp[3] = re.sub("。", "", temp[3])
                                qybd_lib["权益变动后股东持股比例（%）"] = temp[3]
                            
                            elif(indicator_name == "目的"):
                                qybd_lib["权益变动原因"] = temp[3]
                                
            tmp = []
            for k in qybd_cal[0]:
                if(k == "权益变动后股东持股数量（股）" and qybd_lib[k].count("不变")):
                    qybd_lib[k] = qybd_lib["权益变动前股东持股数量（股）"]
                tmp.append(qybd_lib[k])
            qybd_cal.append(tmp)
            
    if "收购" in on_off:
        if(pdf_file.count('收购') != 0):
            shougou_lib = {"公告日期":"", "公司名":"", "划出方":"", "划入方":"",
                            "划转标的（股）":"", "标的占划出方持有公司股份比例（%）":"",
                            "收购前股东持股数量（股）":"", "收购前持有公司占比（%）":"",
                            "收购后股东持股数量（股）":"","收购后持有公司占比（%）":""}
            indicators_re = copy.deepcopy(base_indicators_re)
            from dictionary import indicators_shougou_re
            indicators_re = indicators_shougou_re
            from setting import shougou_indicators
            if(pdf_file.count('成都银行')):
                from dictionary import indicators_shougou_re_cd
                indicators_re = indicators_shougou_re_cd
            for sort, texts in shougou_goal_text.items():
                for text in texts:
                    for indicator_name in shougou_indicators[sort]:
                        indic = get_indicators(text, indicators_re[indicator_name])
                        if indic:
                            temp = list( ("收购", sort)+indic.groups() )
                            temp[2] = indicator_name
                            if(indicator_name == "公告日期"):
                                shougou_lib["公告日期"] = temp[3]
                                
                            elif(indicator_name == "收购人名称"):
                                shougou_lib["公司名"] = temp[3]
                                
                            elif(indicator_name == "划出方"):
                                shougou_lib["划出方"] = temp[3]
                                
                            elif(indicator_name == "划入方"):
                                shougou_lib["划入方"] = temp[3]
                                
                            elif(indicator_name == "标的"):
                                if(temp[3].count("未") or temp[3].count("不再")):
                                    temp[3] = "0%"
                                zhanbi = re.search("([\d,\.]*?%)", temp[3]).group(0)
                                zhanbi = re.sub("%", "", zhanbi)
                                zhanbi = re.sub("。", "", zhanbi)
                                gushu = re.search("([\d,\.]*?)股", temp[3]).group(0)
                                gushu = re.sub("%", "", gushu)
                                gushu = re.sub("。", "", gushu)
                                
                                
                                shougou_lib["划转标的（股）"] = gushu
                                shougou_lib["标的占划出方持有公司股份比例（%）"] = zhanbi
                                
                            elif(indicator_name == "收购前持有公司占比"):
                                
                                if(temp[3].count("未") or temp[3].count("不再")):
                                    temp[3] = "0"
                                zhanbi = clean_text(temp[3])
                                zhanbi = re.search("(合计.*[\d,\.]*?)", temp[3]).group(0)
                                zhanbi = re.search("([\d,\.]*?%)", zhanbi).group(0)
                                zhanbi = re.sub("%", "", zhanbi)
                                zhanbi = re.sub("。", "", zhanbi)
                                gushu = clean_text(temp[3])
                                gushu = re.search("(合计.*[\d,\.]*?股)", temp[3]).group(0)
                                gushu = re.search("([\d,\.\s]*?)股", gushu).group(0)
                                gushu = re.sub("%", "", gushu)
                                gushu = re.sub("。", "", gushu)
                                if(gushu == '股'):
                                    gushu = 'N/A'
                                shougou_lib["收购前股东持股数量（股）"] = gushu
                                shougou_lib["收购前持有公司占比（%）"] = zhanbi
                            
                            elif(indicator_name == "收购后持有公司占比"):
                                if(temp[3].count("未") or temp[3].count("不再")):
                                    temp[3] = "0"
                                zhanbi = clean_text(temp[3])
                                zhanbi = re.search("(合计.*[\d,\.]*?)", temp[3]).group(0)
                                zhanbi = re.search("([\d,\.]*?%)", zhanbi).group(0)
                                zhanbi = re.sub("%", "", zhanbi)
                                zhanbi = re.sub("。", "", zhanbi)
                                gushu = clean_text(temp[3])
                                gushu = re.search("(合计.*[\d,\.]*?股)", temp[3]).group(0)
                                gushu = re.search("([\d,\.\s]*?)股", gushu).group(0)
                                gushu = re.sub("%", "", gushu)
                                gushu = re.sub("。", "", gushu)
                                
                                if(gushu == '股'):
                                    gushu = 'N/A'
                                shougou_lib["收购后股东持股数量（股）"] = gushu
                                shougou_lib["收购后持有公司占比（%）"] = zhanbi
                            shougou_indicators_value.append(temp)
            tmp = []
            for k in shougou_cal[0]:
                tmp.append(shougou_lib[k])
            shougou_cal.append(tmp)
    # =================== 从包含指标的目标文本提取指标 ===================
    
    
    
    
    
    # =================== 将收集到的指标数据归并到一个变量内 ===================
    if qybd_indicators_value and shougou_indicators_value:
        indicators_data = qybd_indicators_value + shougou_indicators_value
    elif qybd_indicators_value and not shougou_indicators_value:
        indicators_data = qybd_indicators_value
    elif not qybd_indicators_value and shougou_indicators_value:
        indicators_data = shougou_indicators_value
    else:
        print("没有收集到任何指标数据，文件不会生成，程序将退出")
        exit(3)
    
    # 清洗变化的数据
    from setting import clean_change
    from tool import clean_data
    for item in indicators_data:
        # 清洗变化的数据
        if(len(item) > 4):
            item[4] = clean_change(item[4])
        # 清除字符串左右两边空白符
        if(len(item[3]) > 0 and (item[3][0] == '。' or item[3][0] == '，')):
            item[3] = item[3][1:]
        item[3] = clean_data(item[3])
    # 清洗变化的数据
    from setting import clean_change
    from tool import clean_data
    for i in range(len(indicators_data)):

        if(len(indicators_data[i]) > 4):
            indicators_data[i] = indicators_data[i][0:4]
        # 清除字符串左右两边空白符
        indicators_data[i][3] = clean_data(indicators_data[i][3])
    
    # =================== 将收集到的指标数据归并到一个变量内 ===================
    
    df = pd.DataFrame(indicators_data, columns=["分类1","分类2","指标名","指标值"])
    file_name = "指标数据" + pdf_file[0:-4] + ".xlsx"
    df.to_excel(file_name, index = False)

    
    
    # # # =================== Process data and reformat ===================
    
    # from setting import find_special,method_changes, method_changes_value,specialcase_value
    # from setting import reformat_period,reformat_change
    
    # df = pd.DataFrame(indicators_data, columns=["分类1","分类2","指标名","指标值","变化"])
    # df_ = find_special(df)
    
    
    # units = ['%','亿元','个百分点','个基点']
    # kw_col_df = kb_df[0:4]
    # pos_neg_df = kb_df[(kb_df.proposed_columns == '+') | (kb_df.proposed_columns == '-')]
    
    # df_['changes_indicator'] = df_.apply(method_changes, axis=1,kw_col_df=kw_col_df)
    # df_['changes_value'] = df_.apply(method_changes_value, axis=1, kw_col_df=kw_col_df,pos_neg_df=pos_neg_df,units=units)
    # df_['changes_value'] = df_.apply(specialcase_value, axis=1,kw_col_df=kw_col_df,pos_neg_df=pos_neg_df,units=units)
    
    
    # df_['指标值_截至2020年9月末'] = df_.apply(reformat_period, axis=1, col1='截至2020年9月末', col2 = '指标值')
    # df_['指标值_2020年1-9月'] = df_.apply(reformat_period, axis=1, col1='2020年1-9月', col2 = '指标值')
    # df_['指标值_2020年第三季度'] = df_.apply(reformat_period, axis=1, col1='2020年第三季度', col2 = '指标值')
    # df_['变化_较上年末变化'] = df_.apply(reformat_change, axis=1, col1='较上年末变化', col2 = 'changes_value')
    # df_['变化_较2020年上半年变化'] = df_.apply(reformat_change, axis=1, col1='较2020年上半年变化', col2 = 'changes_value')
    # df_['变化_同比变化'] = df_.apply(reformat_change, axis=1, col1='同比变化', col2 = 'changes_value')
    # df_['变化_环比变化'] = df_.apply(reformat_change, axis=1, col1='环比变化', col2 = 'changes_value')
    
    
    
    
    # # =================== 输出文件 ===================
    # df_[['分类1', '分类2', '指标名', '指标值', '变化','changes_indicator', 'changes_value',]].to_excel(path+'output_final1.xlsx')
    # df_[['分类1','指标名','指标值_截至2020年9月末', '指标值_2020年1-9月',
    #         '指标值_2020年第三季度', '变化_较上年末变化', '变化_较2020年上半年变化', '变化_同比变化', '变化_环比变化']].to_excel(path+'output_final2.xlsx')
    # # =================== 输出文件 ===================
    
    print("文件处理完毕，输出文件为: " + file_name)
    pdf.close()

qybd_df_cal = pd.DataFrame(qybd_cal[1:], columns = qybd_cal[0])
qybd_df_cal = qybd_df_cal.sort_values(by = '公司名')
qybd_cal_fn = "权益变动公告日历.xlsx"
qybd_df_cal.to_excel(qybd_cal_fn, index = False)
shougou_df_cal = pd.DataFrame(shougou_cal[1:], columns = shougou_cal[0])
shougou_df_cal = shougou_df_cal.sort_values(by = '公告日期')
shougou_cal_fn = "收购公告日历.xlsx"
shougou_df_cal.to_excel(shougou_cal_fn, index = False)
