-To run this program, you need to put all the Python files under the same folder with the pdfs.
-You need to first make sure you have installed the following libraries:
re, os,  pdfplumber, pandas, numpy, sys, Ipython, copy
-You can use either IDE or terminal to run the program by simply running the main.py
-System will ask user to enter the Operating System s/he is using and please enter the right one.
-System will automatically check the pdfs in the same directory with main.py and read these pdfs to output the final result. If you have some irrelevant pdfs under the same directory with main.py, it will very likely generate some errors.
-We recommend you use macOS and Python 3.X.