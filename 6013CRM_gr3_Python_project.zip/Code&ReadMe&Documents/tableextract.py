#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 27 09:37:17 2021

@author: brucezeng
"""

import numpy as np
import pandas as pd
import re
import pdfplumber
from IPython.display import display, HTML
import os

def is_number_str(s):
    try:
        float(s)
        return True
    except ValueError:
        pass
    try:
        s = re.sub(",|%| ","",s)
        float(s)
        return True
    except ValueError:
        pass
    return False

def get_pdf_list():
    cwd = os.getcwd()
    pdf_list = [file_name for file_name in os.listdir(cwd) if file_name[-4:]==".pdf"]
    return pdf_list

def test_pdf_table(pdf_list):
    test_pdf = pdf_list[0]
    with pdfplumber.open(test_pdf) as pdf:
        for page_index, page in enumerate(pdf.pages):
            tables = page.extract_tables()
            if page_index == 3:
                break
        
def extract_tables_from_pdf(pdf_name):
    last_table_in_page_list = list()
    correct_tables = list()
    tables_to_do_manually = list()
    with pdfplumber.open(pdf_name) as pdf:
        for page_index, page in enumerate(pdf.pages):
            tables = page.extract_tables()
            if tables:
                last_table_in_page_list.append(tables[-1])
                for table_index, table in enumerate(tables):
                    # 不在一页第一个或者最后一个的表格不存在跨页问题
                    if table_index != 0 and table_index != len(tables)-1:
                        correct_tables.append(table)
                    # 第一页第一个表格和最后一页最后一个表格不存在跨页问题
                    elif (table_index == 0 and page_index == 0) or (table_index == len(tables)-1 and page_index == len(pdf.pages)-1) or len(last_table_in_page_list)==1:
                        correct_tables.append(table)
                    else:
                        if table_index == 0 and len(last_table_in_page_list)>1:
    #                     if table_index == 0 and page_index>0:
                            # 如果这一页（page_index>0）的第一个表格（table_index == 0）和上一页的最后一个表格列数不相等，证明是独立的表格
                            # 把这一页的第一个表格和上一页的最后一个表格都判定为正确
                            if len(table[0]) != len(last_table_in_page_list[-2][0]):
                                correct_tables.append(last_table_in_page_list[-2])
                                correct_tables.append(table)
                            # 如果这一页的第一个表格和上一页的最后一个表格列数相等，
                            # 且这一页的第一个表格的第一行中含有至少一个数字（以 is_number_str() 函数判断），认为这两个表格是连续的，否则认为独立
                            else:
                                if filter(is_number_str,table[0]):
                                    complete_table = last_table_in_page_list[-2] + table
                                    correct_tables.append(complete_table)
                                else:
                                    correct_tables.append(last_table_in_page_list[-2])
                                    correct_tables.append(table)
                            
    return correct_tables

def table_to_excel(pdf_name, table):
    # for pdf_name in pdf_list:
    i = 0
    sec_code = pdf_name.split("_")[0]
    # correct_tables = extract_tables_from_pdf(pdf_name)
    correct_tables = table
    for table in correct_tables:
        df = pd.DataFrame(table[1:],columns = table[0])
        display(df)
        df.to_excel("result\{}_{}.xlsx".format(sec_code,i))
        i+=1
        
def get_df(pdf_name, table):
    correct_tables = table
    df_list = []
    for table in correct_tables:
        df = pd.DataFrame(table[1:],columns = table[0])
        # display(df)
        df_list.append(df)
    return df_list


        
        
        