import re
import os

# 20201031_招商银行股份有限公司2020年第三季度报告全文.pdf 这个文件不能正常读取其中内容，所以使用 20201031_招商银行股份有限公司2020年第三季度报告正文.pdf
# path = "/Users/brucezeng/Library/Mobile Documents/com~apple~CloudDocs/SFI-CUHKSZ/MKT6013/3/Cleaned/收购（需要找的）/OCR/"
path = os.getcwd() + '/'
path_win = os.getcwd() + '\\'
files = os.listdir(path)
pdf_file_l = []
for f in files:
    # if(f.count("pdf") and (f.count("权益") or f.count("收购") or f.count("公告"))):
    if(f.count("pdf")):
        pdf_file_l.append(f)

# pdf_file_l = ["20210402_长沙银行股份有限公司简式权益变动报告书.pdf"]
# pdf_file_l = ["20200111_交通银行简式权益变动报告书.pdf",
#                 "20200111_农业银行简式权益变动报告书.pdf", "20200111_工商银行简式权益变动报告书.pdf",
#               "20200512_宁波银行：关于持股5%以上股东持股比例变动超过1%的提示性公告.pdf", "20200807_宁波银行：股东关于持有公司股份比例变动超过1%的公告.pdf", 
#               "20200815_宁波银行：股东关于持有公司股份比例变动超过1%的公告.pdf", "20200908_宁波银行：股东关于持有公司股份比例变动超过1%的公告.pdf",
#               "20200917_宁波银行：股东关于持有公司股份比例变动超过1%的公告.pdf", "20201024_宁波银行：股东关于持有公司股份比例变动超过1%的公告.pdf",
#               "20210312_中国邮政储蓄银行股份有限公司关于股东权益变动的提示性公告.pdf", "20200630_光大银行收购报告书.pdf",
#                 "20210626_成都银行股份有限公司收购报告书.pdf",
#               "20210227_青岛银行：简式权益变动报告书.pdf", "20210227_青岛银行：简式权益变动报告书（海尔投资发展）.pdf",
#               "20200523_光大银行简式权益变动报告书.pdf", "20210306_成都银行股份有限公司简式权益变动报告书.pdf",
#               "20200703_成都银行简式权益变动报告书.pdf", "20210402_长沙银行股份有限公司简式权益变动报告书.pdf",
#               "20200910_青农商行：简式权益变动报告书.pdf", "20200324_招商银行简式权益变动报告书.pdf", "20200310_北京银行简式权益变动报告书.pdf",
#               "20210506_中国民生银行简式权益变动报告书（华夏人寿）.docx.pdf", "20210506_中国民生银行简式权益变动报告书（东方股份）.docx.pdf",
#               "20210506_中国民生银行简式权益变动报告书（东方有限）.pdf", "20201126_郑州银行：简式权益变动报告书.pdf",
# ]


# kb_file = 'knowledge_base.xlsx'

# 只有在on_off列表中，才会取收集数据
on_off = ["权益变动", "收购"]


qybd_indicators = {
    "信息披露义务人情况": [
        "上市公司名称",
        "信息披露义务人",
        "信息披露义务人持股计划",
        "买卖上市公司股份情况",
        "一致行动人",
        "签署日期",
    ],
    "权益变动情况": [
        "目的",
        "方式",
        "权益变动前股东持股数量",
        "权益变动前股东持股占比",
        "权益变动后股东持股数量",
        "权益变动后股东持股占比",
        "股份限制情况",
        "其他重大事项",
    ],
}

# 用于权益变动提示性文件
qybd_indicators_tishi = {
    "信息披露义务人情况": [
        "上市公司名称",
        "信息披露义务人",
        "权益变动日期",
    ],
    "权益变动情况": [
        "方式",
        "权益变动前股东持股数量",
        "权益变动前股东持股占比",
        "权益变动后股东持股数量",
        "权益变动后股东持股占比",
        "股份限制情况",
        # "其他重大事项",
    ],
}

#用于收购报告书
shougou_indicators = {
    "收购人情况": [
        "收购人名称",
        "收购目的",
        "股份计划",
        "买卖行为",
        "公告日期",
    ],
    "收购事件": [
        "标的",
        "划出方",
        "划入方",
        "收购程序",
        "收购方式",
        "股份权利限制情况",
        "资金来源",
        "影响",
        "是否需要发出要约",
    ],
    "股份变动情况": [
        "收购前持有公司占比",
        "收购后持有公司占比",
    ],
}


# 匹配权益变更段落的正则表达式
qybd_sections_re = [
    re.compile("(上市公司名称[\S\s]*?\n)"),
    re.compile("(签*\s?署*\s?日\s?期\s?[\S\s]*?\n)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+基+本+情+况+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+.*未+来+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*目+的+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*方+式+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+前+后+.*情+况+[\S\s]*?\n)([\D]、 ?)"),
    re.compile("((.*)、\s*.*一致行动人.*信息.*披露[\S\s]*?\n)(.*节 ?)"),
    re.compile("((.*)\s*.*前*六*个*月*内*买卖上市公司股份的*情况\n\D*)(\d*)"),
    re.compile("((.*)、\s*.*信息披露义务人.*权利限制情*况[\S\s]*?\n)(\d|\D、|.*节 ?)"),
    re.compile("((.*)\s*.*其他重大事项\n\D*)([\S\s]*.*节 ?)"),
    
    #qingdaoyinhang
    re.compile("((.*)、\s*.*信息披露义务人\S*一致行动.*[\S\s]*?\n)(.*节 ?)"),
    re.compile("(第.节\s*前\s?6\s?个*月*内*买卖上市公司股份的*情况\s?\n\D*)(\d*)"),
    re.compile("(第.节\s*其他重大事项\s\n\D*)(\D\d*)"),
    re.compile("(.、\s?信息披露义务人在上市公司[\s\S]*限制[\D\d]*?)([一二三四五六七八]、\D\d*)"),
]

qybd_sections_hzyh_re = [
    re.compile("(证券简称\S*)"),
    re.compile("(基本情况\s?\n?[\S\s]*)"),

]

qybd_sections_jtnygs_re = [
    re.compile("(上市公司名称[\S\s]*?\n)"),
    re.compile("(签*\s?署*\s?日\s?期\s?[\S\s]*?\n)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+基+本+情+况+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+.*未+来+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*目+的+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*方+式+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+前+后+.*情+况+[\S\s]*?\n)([\D]、 ?)"),
    re.compile("((.*)、\s*.*一致行动人.*信息.*披露[\S\s]*?\n)(.*节 ?)"),
    re.compile("((.*)\s*.*前*六*个*月*内*买卖上市公司股份的*情况\n\D*)(\d*)"),
    re.compile("((.*)、\s*.*信息披露义务人.*权利限制情*况[\S\s]*?\n)(\d|\D、|.*节 ?)"),
    re.compile("((.*)\s*.*其他重大事项\n\D*)([\S\s]*.*节 ?)"),
]

qybd_sections_zhengzhou_re = [
    re.compile("(上市公司名称[\S\s]*?\n)"),
    re.compile("(签*\s?署*\s?日\s?期\s?[\S\s]*?\n)"),
    re.compile("(信息披露义务人)(.*)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+.*未+来+[\S\s]*?\n)(.*第.节)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*目+的+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("(\s?前六个月内买卖.*股份的情况 \n[\s\n\D\S]*?)(第.节)"),
    re.compile("((.*)\s*.*其他重大事项\n\D*)([\S\s]*.*节 ?)"),
    
    #qingdaoyinhang
    re.compile("((.*)、\s*.*信息披露义务人\S*一致行动.*[\S\s]*?\n)(.*节 ?)"),
    re.compile("(第.节\s*前\s?6\s?个*月*内*买卖上市公司股份的*情况\s?\n\D*)(\d*)"),
    re.compile("(第.节\s*其他重大事项\s\n\D*)(\D\d*)"),
    re.compile("(.、\s?信息披露义务人在上市公司[\s\S]*限制[\D\d]*?)([一二三四五六七八]、\D\d*)"),
    
]

qybd_sections_minsheng_re = [
    re.compile("(上市公司名称[\S\s]*?\n)"),
    re.compile("(信息披露义务人名称[：:].*)"),
    re.compile("(签*\s?署*\s?日\s?期\s?[\S\s]*?\n)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+基+本+情+况+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("(信息披露义务人持有、控制其他上市公司股份情况\n[\S\d.\n ]*)第三节"),
    re.compile("((.*)、\s*.*一致行动人.*信息.*披露[\S\s]*?\n)(\D、|.*节 ?)"),
    re.compile("((.*)、\s*.*信息披露义务人.*权利限制情*况[\S\s]*?\n)(\d|\D、|.*节 ?)"),
    re.compile("((.*)\.\s*基+本+情+况+[\S\s]*?\n)((.*)\. ?)"),
    re.compile("(证券简称\D*)(\s|\n)"),
    
    # 民生_华夏人寿&东方有限&东方股份（三套共性）
    re.compile("( 第三节 .*权+益+变+动+.*目+的+[\S\s]*?)(12)"),
    re.compile("(\s*.*其他重大事项 \n\D*)"),
    re.compile("(\s*.*未+来+[\S\s]*?\n)(\s\n)"),
    re.compile("([90] \n.*前*6*个*月*内*买卖上市交易股份的情况 [\S\s]*?\n.*)(.*。)"),

]

qybd_sections_guangda_re = [
    re.compile("(上市公司名称[\S\s]*?\n)"),
    re.compile("(签*\s?署*\s?日\s?期\s?[\S\s]*?\n)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+基+本+情+况+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("(信息披露义务人基本情况[. \n\S]*)765"),#
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+.*未+来+[\S\s]*?\n[\S\n\d]*)"),#光大银行
    re.compile("(信息披露义务人持有、控制其他上市公司股份情况\n[\S\d.\n ]*)第三节"),
    re.compile("((.*)、\s*.*权+益+变+动+.*目+的+[\S\s]*?\n)([\S\d] )"),#光大银行 
    re.compile("((.*)、\s*.*权+益+变+动+.*方+式+[\S\s]*?\n)([\S\d] )"),#光大银行 #成都银行0703
    re.compile("((.*)、\s*.*权+益+变+动+前+后+.*情+况+[\S\s]*?\n)([\D]、 ?)"),
    re.compile("(本次权益变动前持股情况[ \n\S]*4.97%)。"),##成都银行0306
    re.compile("(股权变更前+.[\S \d.,]*\n[\S\d ]*\n\S*)"),#光大银行
    re.compile("((.*)、\s*.*一致行动人.*信息.*披露[\S\s]*?\n)(\D、|.*节 ?)"),
    re.compile("(前六个月买卖上市公司股份的?情况\s?\n\D*)(\d*)"),
    re.compile("((.*)、\s*.*信息披露义务人.*权利限制情*况[\S\s]*?\n)(\d|\D、|.*节 ?)"),
    re.compile("((.*)\s*.*其他重大事项\n\D*)([\S\s]*.*节 ?)"),
    re.compile("(第\s?.\s?节\s*其他重大事项\s\n\D*)(\D\d*)"),
    re.compile("((.*)\.\s*基+本+情+况+[\S\s]*?\n)((.*)\. ?)"),
    re.compile("(证券简称\D*)(\s|\n)"),
    re.compile("((.*) 、.*权利限制情况[\S\s]*?\n)(\d|\D、.*节 ?)")
    
]

qybd_sections_chengdu0306_re = [
    re.compile("(上市公司名称[\S\s]*?\n)"),
    re.compile("(签*\s?署*\s?日\s?期\s?[\S\s]*?\n)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+基+本+情+况+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+.*未+来+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*目+的+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("(本次权益变动前持股情况[ \n\S]*4.97%)。"),##成都银行0306
    re.compile("(前 6 个月内买卖上市公司股份的情况 \n[\S \n]*)10"),#成都银行0306
    re.compile("(信息披露人义务人在上市公司中拥有权益股份的权利限制情况[\S\s\n\d]*) 9"),#成都银行0306
    re.compile("(其它重大事项 \n*\S*\n\S*\n\S*)"),
]

qybd_sections_chengdu0703_re = [
    re.compile("(上市公司名称[\S\s]*?\n)"),
    re.compile("(签*\s?署*\s?日\s?期\s?[\S\s]*?\n)"),
    re.compile("((.*)、信+息+披+露+义+务+人+.基*本*情+况+[\S\s]*?\n)(二、 ?)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+.*未+来+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*目+的+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*方+式+[\S\s]*?\n)([\S\d] )"),#光大银行 #成都银行0703
    re.compile("(本次权益变动涉及的标的股份权利限制情况说明[\S\s]*)(第.节)"),#成都银行0306
]

qybd_sections_changsha_re = [
    re.compile("(上市公司名称[\S\s]*?\n)"),
    re.compile("(签*\s?署*\s?日\s?期\s?[\S\s]*?\n)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+基+本+情+况+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+.*未+来+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*目+的+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+前+后+.*情+况+[\S\s]*?\n)([\D]、 ?)"),
    re.compile("((.*)、\s*.*一致行动人.*信息.*披露[\S\s]*?\n)(\D、|.*节 ?)"),
    re.compile("(前 6 个月买卖上市公司股份的情况 \n[\D\d]*)第六节"),#长沙银行
    re.compile("((.*)、\s*.*信息披露义务人.*权利限制情*况[\S\s]*?\n)(\d|\D、|.*节 ?)"),
    re.compile("(\s\s其他重大事项[\S\s]*\n)(第.节)")
]

qybd_sections_qingnong_re = [
    re.compile("(上市公司名称[\S\s]*?\n)"),
    re.compile("(签*\s?署*\s?日\s?期\s?[\S\s]*?\n)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+基+本+情+况+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+.*未+来+[\S\s]*?\n)(\s?第.章)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*目+的+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*方+式+[\S\s]*?\n)([\S\d] )"),#光大银行 #成都银行0703
    re.compile("((.*)、\s*.*权+益+变+动+前+后+.*情+况+[\S\s]*?\n)([\D]、 ?)"),
    re.compile("(信息披露义务人前六个月买卖.*股份的情况\s\n[\S \n]*)(第.章)"),#成都银行0306
    re.compile("(.、.*权益变动.*权利限制的情况\s\n\D*)(\S)"),
]

qybd_sections_zhaoshang_re = [
    re.compile("(上市公司名称[\S\s]*?\n)"),
    re.compile("(签*\s?署*\s?日\s?期\s?[\S\s]*?\n)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+基+本+情+况+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("(信息披露义务人持有、控制其他上市公司股份情况\n[\S\d.\n ]*)第三节"),
    re.compile("(目的\n.*[.\n\S]* [.\n\S]* [.\n\S]*。)"),#招商银行
    re.compile("(权益变动方式\n[.\S ]*\n[.\S ]*\n[.\S ]*\n[.\S ]*\n)"),#招商银行
    re.compile("第五节(前*6*个*月*内*买卖上市公司交易股份的*情况\n[\S\d\n]*)。"),#招商银行
    re.compile("(信息披露义务人.*上市公司.*受到限制[\s\D]*)"),
    re.compile("((.*)\s*.*其他重大事项\n\D*)([\S\s]*.*节 ?)"),
    re.compile("(东变更，\s[\s\S]*)(信息披霹义务人是否拟于)"),
    

]

qybd_sections_beijing_re = [
    re.compile("(上市公司名称[\S\s]*?\n)"),
    re.compile("(签*\s?署*\s?日\s?期\s?[\S\s]*?\n)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+基+本+情+况+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*信+息+披+露+义+务+人+.*未+来+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*目+的+[\S\s]*?\n)([\S1]、 ?)"),
    re.compile("((.*)、\s*.*权+益+变+动+.*方+式+[\S\s]*?)(.、)"),#光大银行 #成都银行0703
    re.compile("((.*)、\s*.*权+益+变+动+前+后+.*情+况+[\S\s]*?\n)([\D]、 ?)"),
    re.compile("(\s\s前六个月内买卖上市交易股份的情况\s\n[\S\s]*)(第.节\s*其他)"),
    re.compile("(\s\s其他重大事项\s\n[\S\s]*)(第.节)"),
    re.compile("((.*)、\s*.*信息披露义务人.*权利限制情*况[\S\s]*?\n)(\d|\D、|.*节 ?)"),
    
]

qybd_sections_yzcx_re = [
    re.compile("(信息披露义务人的基本情况 \n[\S\s]*?\n*。)"),
    re.compile("(本次权益变动方式[\S\s]*?\n*。)"),    
    re.compile("(特此公告[\S\s]*?\n)(\d)"),
]

# 匹配收购段落的正则表达式
shougou_sections_re = [
    re.compile("(\s*收购报告书[\S\s]*?\n)(声\s*明)"),
    re.compile("((.*)、.*收购.*目的[\S\s]*?\n)([\S] 、 ?)"),
    re.compile("((.*)、.*未来[12十二]*.*股份[\S\s]*?\n)([\S] 、 ?)"),
    re.compile("(收购人、收购人的一致行动人自相关事实发生之日前 6 个月[\S\s]*?\n)([\S] 、?)"),
    re.compile("((.*)、.*本次收购.*基本情况[\S\s]*?\n)([\S] 、 ?)"),
    re.compile("((.*)、收购人作出本次收购决定所履行的授权或审批程序[\S\s]*?\n)([\S] 、 ?)"),
    re.compile("((.*)、.*股份权利受到限制的情况[\S\s]*?\n)([\S] 、 ?)"),
    re.compile("((.*)、.*独立性的影响[\S\s]*?\n)([\S] 、 ?)"),
    re.compile("((.*)、本次收购前后收购人及其一致行动人拥有上市公司股份情况[\S\s]*?\n)([\S] 、 ?)"),
]

shougou_sections_cd_re = [
    re.compile("((.*)、.*收购的目的 \n近[\S\s]*?\n)([\S]、 ?)"),
    re.compile("(\s*收购报告书[\S\s]*?\n)(收购人声明)"),
    re.compile("(收购人声明 \n\s\n\S[\S\s]*?\n)([\S]、 ?)"),
    re.compile("((程序。 \n.*)、.*未来12个月继续增持上市公司股份或转让已拥有股份的计划 [\S\s]*?\n)([\S] ?、 ?)"),
    re.compile("((收购报告书 \n.*)第九节  前六个月内买卖上市公司股份的情况 [\S\s]*?\n.*)(收购报告书)"),
    re.compile("(本次无偿划转的标的 \n.*\n.*)"),
    re.compile("(划出方 [\S\n]*)(。 )"),
    re.compile("(划入方 [\S\n]*)(。 )"),
    re.compile("(控股股东。 \n二、本次收购所履行的程序及时间 [\S\s]*?\n)([\S]、)"),
    re.compile("(（二）本次收购简要情况 [\S\s]*?\n)(（三）)"),
    re.compile("(处置。 \n四、本次收购相关股份的权利限制情况 [\S\s]*?\n*。)"),
    re.compile("(第四节  资金来源 \n[\S\s]*?\n*)(第五节)"),
    re.compile("(第七节  对上市公司的影响分析 \n[\S\s]*?\n*。”)"),
    re.compile("(一、收购人持有上市公司股份情况 \n[\S\s]*?\n*。)"),
    re.compile("(本次收购完成后，[\S\s]*?\n*。 \n)(二、本次收购的基本情况 )"),
]

# 匹配分类的文本的正则
qybd_goal_text_re = {
    "信息披露义务人情况": re.compile("(.*)(.*节*.*\n*)"),
    "权益变动情况": re.compile("(.*)(.*节*.*\n*)"),

}

shougou_goal_text_re = {
    "收购人情况": re.compile("(.*)(.*节*.*\n*)"),
    "收购事件": re.compile("(.*)(.*节*.*\n*)"),
    "股份变动情况": re.compile("(本次收购前后收购人及其一致行动人拥有上市公司股份情况.*|本次收购[前完]，?成?后?.*)(.*节*.*\n*)"),
}


# 用于去掉文本中包含的pdf的页头页脚和换行符
# 适用收购报告书
def clean_text(text):
    result = re.sub("(\s+\d+\s+.*有限公司收购报告书\s+)", "", text)
    result = re.sub("：","",result)
    result = re.sub(":","",result)
    result = re.sub("\n", "", result)
    return result


# 用于清洗变化的数据
def clean_change(text):
    if text:
        r = re.search("，.*(?:同比|环比|较|比){1}[^，]*", text)
        if r: return r.group()[1:]
    return ""


######process the data column 变化
#####find the special case in df and marked it at 'same' = 1
def find_special(df):
    
    for k in range(0, len(df)-1):
        if df['变化'].iloc[k+1] in df['变化'].iloc[k]:
                        
            df.at[k,'same'] = 1
            df.at[k+1,'same'] = 1
            
            df.at[k,'group_no'] = 0
            df.at[k+1,'group_no'] = 1           
            
    return df



def method_changes(row,kw_col_df):
    res = None
    for g in range(0, len(kw_col_df)):
    
        if len(re.findall(kw_col_df['keywords'].iloc[g],row['变化'])) > 0:
            res = kw_col_df['proposed_columns'].iloc[g]
            break
        
    
    return res 



#######create the new columns 'changes_values' (extract data from columns:变化)
def method_changes_value(row, kw_col_df, pos_neg_df, units):

    ########extract values on regular string: 同比增长8.35%，在营业收入中占比37.44%
    res = None
    flag = False
    sent = row['变化']
    each = sent.split('，')

    for p in range(0, len(each)):
        
        if flag == True:
            break
        else:
            
            for g in range(0, len(kw_col_df)):
        
                for m in range(0, len(units)):
                    
                    reg1 = kw_col_df['keywords'].iloc[g]+'.*(\d{3,4}\.\d+'+units[m]+')'
                    reg2 = kw_col_df['keywords'].iloc[g]+'.*(\d{2,3}\.\d+'+units[m]+')'
                    reg3 = kw_col_df['keywords'].iloc[g]+'.*(\d{1,2}\.\d+'+units[m]+')'
                    
                    if len(re.findall(reg1,each[p])) > 0:
                        val = re.findall(reg1,each[p])[0]
                        res = val
                        flag = True
                        sent_no = p
                        break
    
                    elif len(re.findall(reg2,each[p])) > 0:
                        val = re.findall(reg2,each[p])[0]
                        res = val
                        flag = True
                        sent_no = p
    
                        break
    
                    elif len(re.findall(reg3,each[p])) > 0:
                        val = re.findall(reg3,each[p])[0]
                        res = val
                        flag = True
                        sent_no = p
    
                        break                
                

    if res != None:
        for n in range(0, len(pos_neg_df)):
            if len(re.findall(pos_neg_df['keywords'].iloc[n],each[sent_no])) > 0:
                sign_ = pos_neg_df['proposed_columns'].iloc[n]
                res = sign_+res
                break
    
    

    return res 



#######special handling cases: 'changes_values' (extract data from columns:变化)

def specialcase_value(row,kw_col_df, pos_neg_df, units ):
    
    res = row['changes_value']
    
    ####usually in this format: 环比分别上升6和8个基点
    if row['same'] == 1:
        sent = row['变化']
        each = sent.split('，')
    
        for p in range(0, len(each)):
    
            for g in range(0, len(kw_col_df)):
                
                for m in range(0, len(units)):
                
                    if len(re.findall(kw_col_df['keywords'].iloc[g]+'.*'+units[m], each[p])) > 0:
                        
                        values = re.findall('\d+',each[p])
                        
                        if len(values) == 2:
                            if row['group_no'] == 0:
                                val= values[0]
                                
                            elif row['group_no'] == 1:
                                val= values[1]
                            
                            for n in range(0, len(pos_neg_df)):
                                if len(re.findall(pos_neg_df['keywords'].iloc[n],each[p])) > 0:
                                    sign_ = pos_neg_df['proposed_columns'].iloc[n]
                                    res = sign_+val+units[m]
                            
    
    return res 


#############reformatting 

def reformat_period(row,col1,col2):
    
    res= None
    if row['分类2'] == col1:
        res = row[col2]
    
    return res 


def reformat_change(row,col1,col2):
    
    res= None
    if row['changes_indicator'] == col1:
        res = row[col2]
    
    return res 
